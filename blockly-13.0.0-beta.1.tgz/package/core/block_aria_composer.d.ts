/**
 * @license
 * Copyright 2026 Raspberry Pi Foundation
 * SPDX-License-Identifier: Apache-2.0
 */
import type { BlockSvg } from './block_svg.js';
import type { Input } from './inputs/input.js';
import { RenderedConnection } from './rendered_connection.js';
import { Verbosity } from './utils/aria.js';
/**
 * Prepositions to use when describing the relationship between two blocks based
 * on their connection types.
 */
export declare enum ConnectionPreposition {
    UNKNOWN = 0,
    BEFORE = 1,
    AFTER = 2,
    AROUND = 3,
    INSIDE = 4
}
/**
 * Returns an ARIA representation of the specified block.
 *
 * The returned label will contain a complete context of the block, including:
 * - Whether it begins a block stack or statement input stack.
 * - Its constituent editable and non-editable fields.
 * - Properties, including: disabled, collapsed, replaceable (a shadow), etc.
 * - Its parent toolbox category.
 * - Whether it has inputs.
 *
 * Beyond this, the returned label is specifically assembled with commas in
 * select locations with the intention of better 'prosody' in the screen reader
 * readouts since there's a lot of information being shared with the user. The
 * returned label also places more important information earlier in the label so
 * that the user gets the most important context as soon as possible in case
 * they wish to stop readout early.
 *
 * The returned label will be specialized based on whether the block is part of a
 * flyout.
 *
 * @internal
 * @param block The block for which an ARIA representation should be created.
 * @param verbosity How much detail to include in the description.
 * @returns The ARIA representation for the specified block.
 */
export declare function computeAriaLabel(block: BlockSvg, verbosity?: Verbosity): string;
/**
 * Sets the ARIA role and role description for the specified block, accounting
 * for whether the block is part of a flyout.
 *
 * @internal
 * @param block The block to set ARIA role and roledescription attributes on.
 */
export declare function configureAriaRole(block: BlockSvg): void;
/**
 * Returns a list of ARIA labels for the 'field row' for the specified Input.
 *
 * 'Field row' essentially means the horizontal run of readable fields that
 * precede the Input. Together, these provide the domain context for the input,
 * particularly in the context of connections. In some cases, there may not be
 * any readable fields immediately prior to the Input. In that case, if the
 * `lookback` attribute is specified, all of the fields on the row immediately
 * above the Input will be used instead.
 *
 * @internal
 * @param input The Input to compute a description/context label for.
 * @param lookback If true, will use labels for fields on the previous row if
 *     the given input's row has no fields itself.
 * @returns A list of labels for fields on the same row (or previous row, if
 *     lookback is specified) as the given input.
 */
export declare function computeFieldRowLabel(input: Input, lookback: boolean, verbosity?: Verbosity): string[];
/**
 * Returns a list of accessibility labels for fields and inputs on a block.
 * Each entry in the returned array corresponds to one of: (a) a label for a
 * continuous run of non-interactable fields, (b) a label for an editable field,
 * (c) a label for an input. When an input contains nested blocks/fields/inputs,
 * their contents are returned as a single item in the array per top-level
 * input.
 *
 * @internal
 * @param block The block to retrieve a list of field/input labels for.
 * @returns A list of field/input labels for the given block.
 */
export declare function getInputLabels(block: BlockSvg, verbosity?: Verbosity): string[];
/**
 * Returns a subset of labels for inputs on the given block, ending at the
 * specified input.
 *
 * The subset is determined based on the input type:
 * - For non-statement inputs, only the label for the given input is returned.
 * - For statement inputs, labels are collected from the start of the current
 *   statement section up to and including the given input. A statement section
 *   begins immediately after the previous statement input, or at the start of
 *   the block if none exists.
 *
 * @internal
 * @param block The block to retrieve a list of field/input labels for.
 * @param input The input that defines the end of the subset.
 * @returns A list of field/input labels for the given block.
 */
export declare function getInputLabelsSubset(block: BlockSvg, input: Input, verbosity?: Verbosity): string[];
/**
 * Returns a translated string describing an in-progress move of a block to a new
 * connection, suitable for announcement on the ARIA live region. The returned string
 * will be assembled based on the types of the local and neighbour connections and
 * the presence of any readable fields on the block's inputs. If multiple potential
 * candidate connections are present, additional context will be included in the
 * returned string to help disambiguate between them.
 *
 * @param local The moving side of the candidate connection pair
 * @param neighbour The target side of the candidate connection pair
 * @param disambiguationPolicy A function that determines whether it's useful to
 *     include parent input labels for disambiguation.
 * @param isMoveStart Whether this announcement is for the start of a move. If false,
 *     skip announcing the block label since it should have already been announced.
 */
export declare function computeMoveLabel(local: RenderedConnection, neighbour: RenderedConnection, disambiguationPolicy: (forLocal: boolean) => boolean, isMoveStart?: boolean): string;
//# sourceMappingURL=block_aria_composer.d.ts.map